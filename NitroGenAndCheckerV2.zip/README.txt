I-----    I-------       /\         I----\
I     -   I             /  \        I     \
I    -    I            /    \       I      \
I----     I-------    /------\      I      I   ---------
I \       I          /        \     I      /
I  \      I         /          \    I     /
I   \     I------- /            \   I----/





I\        /I        I----------
I \      / I        I
I  \    /  I        I
I   \  /   I        I
I    \/    I        I----------
I          I        I
I          I        I
I          I        I
I          I        I----------




Please Note that this "Script" Was Maded By AngerMinecraftY (This Creator) And That This Script Only For Him Is NOT Pubic!

(Only That Big ANONIX logo was copyed and pasted from an ohter user)

This Product Was Licenced Under The Replit.com Rules And Licenses

Want to get the Script? Contact me on disccord:AngerMinecraftYT#2748


This Product Was Licenced And Given To: You And Ohter Users